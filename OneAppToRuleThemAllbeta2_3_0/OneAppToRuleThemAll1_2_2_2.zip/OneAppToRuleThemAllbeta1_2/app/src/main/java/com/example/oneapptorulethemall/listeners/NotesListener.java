package com.example.oneapptorulethemall.listeners;

import com.example.oneapptorulethemall.entities.Note;

public interface NotesListener {
    void onNotesClicked(Note note, int position);
}
