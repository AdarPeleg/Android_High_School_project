package com.example.oneapptorulethemall.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.oneapptorulethemall.R;
import com.example.oneapptorulethemall.activities.CreateNoteActivity;
import com.example.oneapptorulethemall.adapters.NotesAdapter;
import com.example.oneapptorulethemall.database.NotesDatabase;
import com.example.oneapptorulethemall.entities.Note;

import java.util.ArrayList;
import java.util.List;

public class notes_page extends AppCompatActivity {


    public static final int REQUEST_CODE_ADD_NOTE = 1;

    private RecyclerView notesRecyclerView;
    private List<Note> noteList;
    private NotesAdapter notesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes_page);

        ImageView imageAddNoteMain = findViewById(R.id.imageAddNoteMain);
        // on click
        imageAddNoteMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(
                        new Intent(getApplicationContext(), CreateNoteActivity.class),
                        REQUEST_CODE_ADD_NOTE
                );
            }
        });

        // notes recycler view
        notesRecyclerView = findViewById(R.id.notesRecyclerView);
        notesRecyclerView.setLayoutManager(
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        );


        noteList= new ArrayList<>();
        notesAdapter = new NotesAdapter(noteList);
        notesRecyclerView.setAdapter(notesAdapter);


        // render notes
        getNotes();
    }
    // using async
    private void getNotes() {

        @SuppressLint("StaticFieldLeak")
        class GetNoteTask extends AsyncTask<Void, Void, List<Note>>{

            @Override
            protected List<Note> doInBackground(Void... voids) {
                return NotesDatabase
                        .getDataBase(getApplicationContext())
                        .noteDao().getAllNotes();
            }


            /*
            * if note list is empty it means the app just started because it's globle variable
            *  and we need to  update(add all notes) from db to list.
            * else that means that we need to add only one note
            * and scroll recycler view to the top
            * */
            @Override
            protected void onPostExecute(List<Note> notes) {
                super.onPostExecute(notes);
                Log.d("my_notes", notes.toString()); // debugging
                Log.d("my_notes_size", String.valueOf(noteList.size())); // debugging
                if(noteList.size() ==0){
                    noteList.addAll(notes);
                    Log.d("my_notes_size", String.valueOf(noteList.size())); // debugging
                    notesAdapter.notifyDataSetChanged();
                }else{
                    noteList.add(0, notes.get(0));
                    notesAdapter.notifyItemInserted(0);
                }
                notesRecyclerView.smoothScrollToPosition(0);

            }
        }
        new GetNoteTask().execute();
    }


    // update note real time (after save button pressed!)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // result code checks if createnote activity is done
        if(requestCode == REQUEST_CODE_ADD_NOTE && resultCode == RESULT_OK){
            getNotes();
        }

    }
}