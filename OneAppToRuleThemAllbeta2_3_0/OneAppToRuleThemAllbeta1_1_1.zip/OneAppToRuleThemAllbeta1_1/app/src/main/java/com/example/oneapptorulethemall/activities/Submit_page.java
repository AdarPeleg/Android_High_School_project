package com.example.oneapptorulethemall.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.oneapptorulethemall.R;
import com.example.oneapptorulethemall.add_NewBook;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Submit_page extends AppCompatActivity {


    RecyclerView recyclerView;
    FloatingActionButton addbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_page);


        recyclerView = findViewById(R.id.recyclerView);
        addbtn = findViewById(R.id.addbtn);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), add_NewBook.class);
                startActivity(intent);
            }
        });
    }

}